package sw;

import java.util.ArrayList;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import modelo.Usuario;

@WebService(serviceName = "ConversionSW")
public class ConversionSW {

    // Base de datos temporal
    private static ArrayList<Usuario> listaUsuarios = new ArrayList<>();

    // REGISTRAR
    @WebMethod(operationName = "registrarUsuario")
    public String registrarUsuario(
            @WebParam(name = "usuario") String usuario,
            @WebParam(name = "clave") String clave,
            @WebParam(name = "saldo") double saldo) {

        for (Usuario u : listaUsuarios) {
            if (u.getUsuario().equals(usuario)) {
                return "El usuario ya existe";
            }
        }

        Usuario nuevo = new Usuario(usuario, clave, saldo);
        listaUsuarios.add(nuevo);

        return "Usuario registrado con éxito";
    }

    // LOGIN
    @WebMethod(operationName = "login")
    public boolean login(
            @WebParam(name = "usuario") String usuario,
            @WebParam(name = "clave") String clave) {

        for (Usuario u : listaUsuarios) {
            if (u.getUsuario().equals(usuario)
                    && u.getClave().equals(clave)) {

                return true;
            }
        }

        return false;
    }

    // OBTENER SALDO
    @WebMethod(operationName = "obtenerSaldo")
    public double obtenerSaldo(
            @WebParam(name = "usuario") String usuario) {

        for (Usuario u : listaUsuarios) {
            if (u.getUsuario().equals(usuario)) {
                return u.getSaldo();
            }
        }

        return 0;
    }

    // DEPOSITAR
    @WebMethod(operationName = "depositar")
    public String depositar(
            @WebParam(name = "usuario") String usuario,
            @WebParam(name = "valor") double valor) {

        for (Usuario u : listaUsuarios) {

            if (u.getUsuario().equals(usuario)) {

                u.setSaldo(u.getSaldo() + valor);

                return "Depósito realizado con éxito";
            }
        }

        return "Usuario no encontrado";
    }

    // RETIRAR
    @WebMethod(operationName = "retirar")
    public String retirar(
            @WebParam(name = "usuario") String usuario,
            @WebParam(name = "valor") double valor) {

        for (Usuario u : listaUsuarios) {

            if (u.getUsuario().equals(usuario)) {

                if (valor > u.getSaldo()) {
                    return "Saldo insuficiente";
                }

                u.setSaldo(u.getSaldo() - valor);

                return "Retiro realizado con éxito";
            }
        }

        return "Usuario no encontrado";
    }
}