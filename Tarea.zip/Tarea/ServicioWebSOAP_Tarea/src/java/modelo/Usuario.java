package modelo;

public class Usuario {

    private String usuario;
    private String clave;
    private double saldo;

    public Usuario() {
    }

    public Usuario(String usuario, String clave, double saldo) {
        this.usuario = usuario;
        this.clave = clave;
        this.saldo = saldo;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
}