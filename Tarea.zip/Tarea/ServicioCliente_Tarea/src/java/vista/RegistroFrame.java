package vista;
import javax.swing.JOptionPane;
import sw.ConversionSW;
import sw.ConversionSW_Service;

public class RegistroFrame extends javax.swing.JFrame {

    ConversionSW_Service servicio = new ConversionSW_Service();
    ConversionSW ws = servicio.getConversionSWPort();

    public RegistroFrame() {
        initComponents();
        setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {

        lblTitulo = new javax.swing.JLabel();

        lblUsuario = new javax.swing.JLabel();
        txtUsuario = new javax.swing.JTextField();

        lblClave = new javax.swing.JLabel();
        txtClave = new javax.swing.JPasswordField();

        lblRepetir = new javax.swing.JLabel();
        txtRepetir = new javax.swing.JPasswordField();

        lblSaldo = new javax.swing.JLabel();
        txtSaldo = new javax.swing.JTextField();

        btnRegistrar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        lblTitulo.setFont(new java.awt.Font("Arial", 1, 18));
        lblTitulo.setText("REGISTRO DE USUARIO");

        lblUsuario.setText("Usuario:");

        lblClave.setText("Clave:");

        lblRepetir.setText("Repetir Clave:");

        lblSaldo.setText("Saldo Inicial:");

        btnRegistrar.setText("Registrar");

        btnRegistrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registrar();
            }
        });

        javax.swing.GroupLayout layout =
                new javax.swing.GroupLayout(getContentPane());

        getContentPane().setLayout(layout);

        layout.setHorizontalGroup(
                layout.createParallelGroup(
                        javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(40, 40, 40)
                                .addGroup(layout.createParallelGroup(
                                        javax.swing.GroupLayout.Alignment.LEADING)

                                        .addComponent(lblTitulo)

                                        .addComponent(lblUsuario)
                                        .addComponent(txtUsuario,
                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                220,
                                                javax.swing.GroupLayout.PREFERRED_SIZE)

                                        .addComponent(lblClave)
                                        .addComponent(txtClave,
                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                220,
                                                javax.swing.GroupLayout.PREFERRED_SIZE)

                                        .addComponent(lblRepetir)
                                        .addComponent(txtRepetir,
                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                220,
                                                javax.swing.GroupLayout.PREFERRED_SIZE)

                                        .addComponent(lblSaldo)
                                        .addComponent(txtSaldo,
                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                220,
                                                javax.swing.GroupLayout.PREFERRED_SIZE)

                                        .addComponent(btnRegistrar))
                                .addContainerGap(40, Short.MAX_VALUE))
        );

        layout.setVerticalGroup(
                layout.createParallelGroup(
                        javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(30, 30, 30)

                                .addComponent(lblTitulo)

                                .addGap(20, 20, 20)

                                .addComponent(lblUsuario)
                                .addGap(5, 5, 5)
                                .addComponent(txtUsuario,
                                        javax.swing.GroupLayout.PREFERRED_SIZE,
                                        30,
                                        javax.swing.GroupLayout.PREFERRED_SIZE)

                                .addGap(15, 15, 15)

                                .addComponent(lblClave)
                                .addGap(5, 5, 5)
                                .addComponent(txtClave,
                                        javax.swing.GroupLayout.PREFERRED_SIZE,
                                        30,
                                        javax.swing.GroupLayout.PREFERRED_SIZE)

                                .addGap(15, 15, 15)

                                .addComponent(lblRepetir)
                                .addGap(5, 5, 5)
                                .addComponent(txtRepetir,
                                        javax.swing.GroupLayout.PREFERRED_SIZE,
                                        30,
                                        javax.swing.GroupLayout.PREFERRED_SIZE)

                                .addGap(15, 15, 15)

                                .addComponent(lblSaldo)
                                .addGap(5, 5, 5)
                                .addComponent(txtSaldo,
                                        javax.swing.GroupLayout.PREFERRED_SIZE,
                                        30,
                                        javax.swing.GroupLayout.PREFERRED_SIZE)

                                .addGap(20, 20, 20)

                                .addComponent(btnRegistrar)

                                .addContainerGap(30, Short.MAX_VALUE))
        );

        pack();
    }

    private void registrar() {

        try {

            String usuario = txtUsuario.getText().trim();

            String clave =
                    String.valueOf(txtClave.getPassword());

            String repetir =
                    String.valueOf(txtRepetir.getPassword());

            if (usuario.isEmpty()
                    || clave.isEmpty()
                    || repetir.isEmpty()
                    || txtSaldo.getText().trim().isEmpty()) {

                JOptionPane.showMessageDialog(this,
                        "Complete todos los campos");

                return;
            }

            if (!clave.equals(repetir)) {

                JOptionPane.showMessageDialog(this,
                        "Las claves no coinciden");

                return;
            }

            double saldo =
                    Double.parseDouble(txtSaldo.getText());

            if (saldo < 0) {

                JOptionPane.showMessageDialog(this,
                        "El saldo debe ser mayor a 0");

                return;
            }

            String respuesta =
                    ws.registrarUsuario(usuario, clave, saldo);

            JOptionPane.showMessageDialog(this, respuesta);

            if (respuesta.equals("Usuario registrado con éxito")) {

                dispose();
            }

        } catch (NumberFormatException e) {

            JOptionPane.showMessageDialog(this,
                    "Ingrese un saldo válido");
        }
    }

    private javax.swing.JButton btnRegistrar;

    private javax.swing.JLabel lblClave;
    private javax.swing.JLabel lblRepetir;
    private javax.swing.JLabel lblSaldo;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JLabel lblUsuario;

    private javax.swing.JPasswordField txtClave;
    private javax.swing.JPasswordField txtRepetir;

    private javax.swing.JTextField txtSaldo;
    private javax.swing.JTextField txtUsuario;
}