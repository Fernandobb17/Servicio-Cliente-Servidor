package vista;
import javax.swing.JOptionPane;
import sw.ConversionSW;
import sw.ConversionSW_Service;

public class TransaccionesFrame extends javax.swing.JFrame {

    private String usuario;

    ConversionSW_Service servicio = new ConversionSW_Service();
    ConversionSW ws = servicio.getConversionSWPort();

    public TransaccionesFrame(String usuario) {

        this.usuario = usuario;

        initComponents();

        setLocationRelativeTo(null);

        cargarSaldo();
    }

    @SuppressWarnings("hola1")
    private void initComponents() {

        lblTitulo = new javax.swing.JLabel();

        lblUsuario = new javax.swing.JLabel();

        lblSaldoTexto = new javax.swing.JLabel();
        lblSaldo = new javax.swing.JLabel();

        rbDeposito = new javax.swing.JRadioButton();
        rbRetiro = new javax.swing.JRadioButton();

        grupo = new javax.swing.ButtonGroup();

        lblValor = new javax.swing.JLabel();
        txtValor = new javax.swing.JTextField();

        btnRegistrar = new javax.swing.JButton();

        grupo.add(rbDeposito);
        grupo.add(rbRetiro);

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        lblTitulo.setFont(new java.awt.Font("Arial", 1, 18));
        lblTitulo.setText("CUENTA DE USUARIO");

        lblUsuario.setFont(new java.awt.Font("Arial", 1, 16));
        lblUsuario.setText(usuario);

        lblSaldoTexto.setText("Saldo:");

        lblSaldo.setFont(new java.awt.Font("Arial", 1, 16));
        lblSaldo.setText("0");

        rbDeposito.setText("Depósito");

        rbRetiro.setText("Retiro");

        lblValor.setText("Valor:");

        btnRegistrar.setText("Registrar");

        btnRegistrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registrarTransaccion();
            }
        });

        javax.swing.GroupLayout layout =
                new javax.swing.GroupLayout(getContentPane());

        getContentPane().setLayout(layout);

        layout.setHorizontalGroup(
                layout.createParallelGroup(
                        javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(40, 40, 40)
                                .addGroup(layout.createParallelGroup(
                                        javax.swing.GroupLayout.Alignment.LEADING)

                                        .addGroup(layout.createSequentialGroup()
                                                .addComponent(lblTitulo)
                                                .addGap(10, 10, 10)
                                                .addComponent(lblUsuario))

                                        .addComponent(lblSaldoTexto)

                                        .addComponent(lblSaldo)

                                        .addComponent(rbDeposito)

                                        .addComponent(rbRetiro)

                                        .addComponent(lblValor)

                                        .addComponent(txtValor,
                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                220,
                                                javax.swing.GroupLayout.PREFERRED_SIZE)

                                        .addComponent(btnRegistrar))
                                .addContainerGap(40, Short.MAX_VALUE))
        );

        layout.setVerticalGroup(
                layout.createParallelGroup(
                        javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(30, 30, 30)

                                .addGroup(layout.createParallelGroup(
                                        javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(lblTitulo)
                                        .addComponent(lblUsuario))

                                .addGap(20, 20, 20)

                                .addComponent(lblSaldoTexto)

                                .addGap(5, 5, 5)

                                .addComponent(lblSaldo)

                                .addGap(20, 20, 20)

                                .addComponent(rbDeposito)

                                .addGap(10, 10, 10)

                                .addComponent(rbRetiro)

                                .addGap(20, 20, 20)

                                .addComponent(lblValor)

                                .addGap(5, 5, 5)

                                .addComponent(txtValor,
                                        javax.swing.GroupLayout.PREFERRED_SIZE,
                                        30,
                                        javax.swing.GroupLayout.PREFERRED_SIZE)

                                .addGap(20, 20, 20)

                                .addComponent(btnRegistrar)

                                .addContainerGap(30, Short.MAX_VALUE))
        );

        pack();
    }

    private void cargarSaldo() {

        double saldo = ws.obtenerSaldo(usuario);

        lblSaldo.setText(String.valueOf(saldo));
    }

    private void registrarTransaccion() {

        try {

            if (txtValor.getText().trim().isEmpty()) {

                JOptionPane.showMessageDialog(this,
                        "Ingrese un valor");

                return;
            }

            double valor =
                    Double.parseDouble(txtValor.getText());

            if (valor <= 0) {

                JOptionPane.showMessageDialog(this,
                        "El valor debe ser mayor a 0");

                return;
            }

            String respuesta = "";

            if (rbDeposito.isSelected()) {

                respuesta = ws.depositar(usuario, valor);

            } else if (rbRetiro.isSelected()) {

                respuesta = ws.retirar(usuario, valor);

            } else {

                JOptionPane.showMessageDialog(this,
                        "Seleccione una opción");

                return;
            }

            JOptionPane.showMessageDialog(this, respuesta);

            cargarSaldo();

            txtValor.setText("");

        } catch (NumberFormatException e) {

            JOptionPane.showMessageDialog(this,
                    "Ingrese un número válido");
        }
    }

    private javax.swing.JButton btnRegistrar;

    private javax.swing.ButtonGroup grupo;

    private javax.swing.JLabel lblSaldo;
    private javax.swing.JLabel lblSaldoTexto;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JLabel lblUsuario;
    private javax.swing.JLabel lblValor;

    private javax.swing.JRadioButton rbDeposito;
    private javax.swing.JRadioButton rbRetiro;

    private javax.swing.JTextField txtValor;
}