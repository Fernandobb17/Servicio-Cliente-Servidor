package vista;

import javax.swing.JOptionPane;
import sw.ConversionSW;
import sw.ConversionSW_Service;

public class LoginFrame extends javax.swing.JFrame {

    ConversionSW_Service servicio = new ConversionSW_Service();
    ConversionSW ws = servicio.getConversionSWPort();

    public LoginFrame() {
        initComponents();
        setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {

        lblUsuario = new javax.swing.JLabel();
        txtUsuario = new javax.swing.JTextField();

        lblClave = new javax.swing.JLabel();
        txtClave = new javax.swing.JPasswordField();

        btnIngresar = new javax.swing.JButton();
        btnRegistro = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblUsuario.setText("Usuario:");

        lblClave.setText("Clave:");

        btnIngresar.setText("Ingresar");

        btnRegistro.setText("Registrar");

        btnIngresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {

                ingresar();
            }
        });

        btnRegistro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {

                RegistroFrame r = new RegistroFrame();
                r.setVisible(true);
            }
        });

        javax.swing.GroupLayout layout =
                new javax.swing.GroupLayout(getContentPane());

        getContentPane().setLayout(layout);

        layout.setHorizontalGroup(
                layout.createParallelGroup(
                        javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(40, 40, 40)
                                .addGroup(layout.createParallelGroup(
                                        javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(btnRegistro)
                                        .addComponent(btnIngresar)
                                        .addComponent(lblUsuario)
                                        .addComponent(txtUsuario,
                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                200,
                                                javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(lblClave)
                                        .addComponent(txtClave,
                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                200,
                                                javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addContainerGap(40, Short.MAX_VALUE))
        );

        layout.setVerticalGroup(
                layout.createParallelGroup(
                        javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(30, 30, 30)
                                .addComponent(lblUsuario)
                                .addGap(10, 10, 10)
                                .addComponent(txtUsuario,
                                        javax.swing.GroupLayout.PREFERRED_SIZE,
                                        30,
                                        javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(20, 20, 20)
                                .addComponent(lblClave)
                                .addGap(10, 10, 10)
                                .addComponent(txtClave,
                                        javax.swing.GroupLayout.PREFERRED_SIZE,
                                        30,
                                        javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(20, 20, 20)
                                .addComponent(btnIngresar)
                                .addGap(15, 15, 15)
                                .addComponent(btnRegistro)
                                .addContainerGap(30, Short.MAX_VALUE))
        );

        pack();
    }

    private void ingresar() {

        String usuario = txtUsuario.getText();
        String clave = String.valueOf(txtClave.getPassword());

        boolean respuesta = ws.login(usuario, clave);

        if (respuesta) {

            JOptionPane.showMessageDialog(this,
                    "Bienvenido");

            TransaccionesFrame t =
                    new TransaccionesFrame(usuario);

            t.setVisible(true);

        } else {

            JOptionPane.showMessageDialog(this,
                    "Usuario o clave incorrecta");
        }
    }

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {

                new LoginFrame().setVisible(true);
            }
        });
    }

    private javax.swing.JButton btnIngresar;
    private javax.swing.JButton btnRegistro;
    private javax.swing.JLabel lblClave;
    private javax.swing.JLabel lblUsuario;
    private javax.swing.JPasswordField txtClave;
    private javax.swing.JTextField txtUsuario;
}